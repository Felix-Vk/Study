#include <iostream>
#include "unique_ptr.hpp"
int main(){
    std::cout << "Smart pointer project placeholder.\n";
    return 0;
}
